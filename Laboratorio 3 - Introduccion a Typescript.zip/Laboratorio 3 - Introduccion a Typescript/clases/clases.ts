interface Animal{

    name:string;
    hacerRuido():void;
}


class Perro implements Animal{

    public name:string;
    
    constructor(name:string){

        this.name = name;

    }

    hacerRuido(){
        console.log("Guau!");
    }

}

class Gato implements Animal{
    public name:string;

    constructor(name:string){
    
        this.name = name;
    
    }
        hacerRuido(){
            console.log("Miau!");
        }
    
    }


var perro:Perro = new Perro("firulais");
var gato:Gato = new Gato("michi");

perro.hacerRuido();
gato.hacerRuido();

var nombre:Array<Animal> = new Array<Animal>();

nombre.push(perro);
nombre.push(gato);

nombre.forEach(function(animal:Animal){

    console.log("Soy "+animal.name);

    animal.hacerRuido();
});