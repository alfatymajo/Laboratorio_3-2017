var Perro = /** @class */ (function () {
    function Perro(name) {
        this.name = name;
    }
    Perro.prototype.hacerRuido = function () {
        console.log("Guau!");
    };
    return Perro;
}());
var Gato = /** @class */ (function () {
    function Gato(name) {
        this.name = name;
    }
    Gato.prototype.hacerRuido = function () {
        console.log("Miau!");
    };
    return Gato;
}());
var perro = new Perro("firulais");
var gato = new Gato("michi");
perro.hacerRuido();
gato.hacerRuido();
var nombre = new Array();
nombre.push(perro);
nombre.push(gato);
nombre.forEach(function (animal) {
    console.log("Soy " + animal.name);
    animal.hacerRuido();
});
