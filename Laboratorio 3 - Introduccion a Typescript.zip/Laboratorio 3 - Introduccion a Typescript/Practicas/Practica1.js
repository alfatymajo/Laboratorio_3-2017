// Tipos
var batman = "Bruce";
var superman = "Clark";
var existe = false;
// Tuplas
var parejaHeroes = [batman, superman];
var villano = ["Lex Lutor", 5, true];
// Arreglos
var aliados = ["Mujer Maravilla", "Acuaman", "San", "Flash"];
//Enumeraciones
var fuerzaFlash = 5;
var fuerzaSuperman = 100;
var fuerzaBatman = 1;
var fuerzaAcuaman = 0;
var Fuerza;
(function (Fuerza) {
    Fuerza[Fuerza["fuerzaFlash"] = 0] = "fuerzaFlash";
    Fuerza[Fuerza["fuerzaSuperman"] = 1] = "fuerzaSuperman";
    Fuerza[Fuerza["fuerzaBatman"] = 2] = "fuerzaBatman";
    Fuerza[Fuerza["fuerzaAcuaman"] = 3] = "fuerzaAcuaman";
})(Fuerza || (Fuerza = {}));
;
// Retorno de funciones
function activar_batiseñal() {
    return "activada";
}
function pedir_ayuda() {
    console.log("Auxilio!!!");
}
// Aserciones de Tipo
var poder = "100";
var largoDelPoder = poder.length;
console.log(largoDelPoder);
