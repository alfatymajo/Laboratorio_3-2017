var personaUno = {"nombre" : "Juan", "apellido" : "Gaita", "edad" : 15};
var personaDos = {"nombre" : "Nicolas", "apellido" : "Copernico", "edad" : 25};
var personaTres = {"nombre" : "Steve", "apellido" : "Jobs", "edad" : 38};
var personaCuatro = {"nombre" : "Galileo", "apellido" : "Galilei", "edad" : 45};

/*
//Primera prueba de objetos json
console.log(personaUno.nombre);
console.log(personaUno.apellido);
console.log(personaUno.edad);
*/
/*
//Prueba de Array de json
var listaPersonas = [personaUno,personaDos,personaTres,personaCuatro];

for (i = 0; i<listaPersonas.length; i++)
{
    console.log(listaPersonas[i].nombre);
    console.log(listaPersonas[i].apellido);
    console.log(listaPersonas[i].edad);
}
*/

var xmlHttp = new XMLHttpRequest();
var callBack = function(){
    
    if (xmlHttp.readyState === 4)
    {
        if (xmlHttp.status === 200)
        {
            console.log("---Llego respuesta del servidor---" + "\n\n");
            var unformatedResponse = xmlHttp.response;

            var listaPersonas = JSON.parse(unformatedResponse);

            for (i = 0; i < listaPersonas.length; i++)
            {
                /*console.log(listaPersonas[i].nombre);
                console.log(listaPersonas[i].apellido);
                console.log(listaPersonas[i].fecha);
                console.log(listaPersonas[i].telefono);*/
                console.info("persona",listaPersonas[i]); 
            }
        }
    }
}

function peticionGetPersonas()
{
    xmlHttp.onreadystatechange = callBack;
    
    var url = "http://localhost:3000/personas";

    xmlHttp.open("GET",url, true);
    //Se indica que el contenido que se va a enviar es de tipo string
    //Solo se indica cuando enviamos por post
    //xmlHttp.setRequestHeader("Content-type","application/json");
  
    xmlHttp.send();
    
    
}
