///<reference path ="./clases/perro.ts"/>
///<reference path ="./clases/animal.ts"/>
///<reference path ="./clases/gato.ts"/>
///<reference path ="./node_modules/@types/jquery/index.d.ts"/>

var perro:animales.Perro = new animales.Perro("firulais");
var gato:animales.Gato = new animales.Gato("michi");

perro.hacerRuido();
gato.hacerRuido();

var nombre:Array<animales.Animal> = new Array<animales.Animal>();

nombre.push(perro);
nombre.push(gato);

$().val;

nombre.forEach(function(animal:animales.Animal){

    console.log("Soy "+animal.name);

    animal.hacerRuido();
});