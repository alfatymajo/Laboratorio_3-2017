///<reference path ="./clases/perro.ts"/>
///<reference path ="./clases/animal.ts"/>
///<reference path ="./clases/gato.ts"/>
///<reference path ="./node_modules/@types/jquery/index.d.ts"/>
var perro = new animales.Perro("firulais");
var gato = new animales.Gato("michi");
perro.hacerRuido();
gato.hacerRuido();
var nombre = new Array();
nombre.push(perro);
nombre.push(gato);
$().val;
nombre.forEach(function (animal) {
    console.log("Soy " + animal.name);
    animal.hacerRuido();
});
