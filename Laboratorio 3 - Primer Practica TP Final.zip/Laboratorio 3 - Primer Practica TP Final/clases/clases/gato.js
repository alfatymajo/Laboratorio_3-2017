///<reference path ="./animal.ts"/>
var animales;
(function (animales) {
    class Gato {
        constructor(name) {
            this.name = name;
        }
        hacerRuido() {
            console.log("Miau!");
        }
    }
    animales.Gato = Gato;
})(animales || (animales = {}));
