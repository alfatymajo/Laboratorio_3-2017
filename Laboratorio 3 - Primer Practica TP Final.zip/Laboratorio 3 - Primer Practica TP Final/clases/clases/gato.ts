///<reference path ="./animal.ts"/>
namespace animales{

export class Gato implements Animal{
    public name:string;

    constructor(name:string){
    
        this.name = name;
    
    }
        hacerRuido(){
            console.log("Miau!");
        }
    
    }
}