namespace animales{

export interface Animal{
    
        name:string;
        hacerRuido():void;
    }
}