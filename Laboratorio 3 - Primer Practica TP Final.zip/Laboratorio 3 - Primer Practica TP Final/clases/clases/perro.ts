
///<reference path ="./animal.ts"/>
namespace animales{

export class Perro implements Animal{
    
        public name:string;
        
        constructor(name:string){
    
            this.name = name;
    
        }
    
        hacerRuido(){
            console.log("Guau!");
        }
    
    }
}