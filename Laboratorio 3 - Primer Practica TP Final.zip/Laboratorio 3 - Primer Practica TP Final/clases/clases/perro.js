///<reference path ="./animal.ts"/>
var animales;
(function (animales) {
    class Perro {
        constructor(name) {
            this.name = name;
        }
        hacerRuido() {
            console.log("Guau!");
        }
    }
    animales.Perro = Perro;
})(animales || (animales = {}));
