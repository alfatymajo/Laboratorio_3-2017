///<reference path ="./persona.ts"/>
var segundo;
(function (segundo) {
    var parcial;
    (function (parcial) {
        class Empleado extends parcial.Persona {
            constructor(nombre, apellido, edad, horario, legajo) {
                super(nombre, apellido, edad);
                this.horario = horario;
                this.legajo = legajo;
            }
            empleadoToJson() {
                let auxEmpleado = super.personaToJson();
                return "el empleado con el personatojson";
            }
        }
        parcial.Empleado = Empleado;
    })(parcial = segundo.parcial || (segundo.parcial = {}));
})(segundo || (segundo = {}));
