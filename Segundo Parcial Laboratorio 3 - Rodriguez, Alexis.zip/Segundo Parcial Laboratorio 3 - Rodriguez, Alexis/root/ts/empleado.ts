///<reference path ="./persona.ts"/>
namespace segundo.parcial {
    export class Empleado extends Persona {
        public horario:string;
        public legajo:number;

        public constructor(nombre:string, apellido:string, edad:number, horario:string, legajo:number) {
            super(nombre,apellido,edad);
            
            this.horario = horario;
            this.legajo = legajo;
        }

        public empleadoToJson()
        {
            let auxEmpleado = super.personaToJson();
            return "el empleado con el personatojson";
        }
    }
}