///<reference path ="../node_modules/@types/jquery/index.d.ts"/>
var man;
(function (man) {
    class manejadora {
        agregarEmpleado() {
        }
        static mostrarEmpleados() {
            let tabla = $("#divtabla");
            tabla.css("visibility", "visible");
        }
        eliminarEmpleado(id) {
        }
        modificarEmpleado(id) {
        }
        filtrarPorHorario() {
        }
        promedioEdadPorHorario() {
        }
        traerDatos(key) {
            return localStorage.getItem(key);
        }
        actualizarLocal(arrayJson) {
            //localStorage.clear();
            localStorage.setItem("datos", arrayJson);
        }
        llenarTablaDatos(idTabla) {
            let tabla = $("#idTabla");
            tabla.html("hola").append(" asdas");
        }
    }
    man.manejadora = manejadora;
})(man || (man = {}));
