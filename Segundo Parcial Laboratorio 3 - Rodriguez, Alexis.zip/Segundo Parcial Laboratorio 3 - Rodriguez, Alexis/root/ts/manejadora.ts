///<reference path ="../node_modules/@types/jquery/index.d.ts"/>

namespace man{ 
    export class manejadora {
    
    public agregarEmpleado()
    {

    }

    public static mostrarEmpleados(){
        let tabla = $("#divtabla");
        tabla.css("visibility","visible");
    }

    public eliminarEmpleado(id:number){

    }

    public  modificarEmpleado(id:number){

    }

    public filtrarPorHorario(){

    }
    
    public promedioEdadPorHorario(){

    }
    
        public traerDatos(key) {

        return localStorage.getItem(key);
    }

    public actualizarLocal(arrayJson) {
        //localStorage.clear();
        localStorage.setItem("datos", arrayJson);
    }

    public llenarTablaDatos(idTabla) {
        let tabla = $("#idTabla");

        tabla.html("hola").append(" asdas");
    }
}
}
