var segundo;
(function (segundo) {
    var parcial;
    (function (parcial) {
        class Persona {
            constructor(nombre, apellido, edad) {
                this.nombre = nombre;
                this.apellido = apellido;
                this.edad = edad;
            }
            personaToJson() {
                return "la clase en formato json";
            }
        }
        parcial.Persona = Persona;
    })(parcial = segundo.parcial || (segundo.parcial = {}));
})(segundo || (segundo = {}));
