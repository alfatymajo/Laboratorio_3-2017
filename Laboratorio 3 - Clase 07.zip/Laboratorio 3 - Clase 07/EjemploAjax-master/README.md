# EjemploAjax
EjemploAjax
http://octaviovillegas.github.io/EjemploAjax/

la Carpeta ServidorPHP se debe colocar en el servidor apache en la carpeta htdocs.
los archivos del frontEnd Pueden estar en cualquier lugar