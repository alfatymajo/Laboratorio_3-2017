
function MostarPaises()
{

	$("#informe").html("<img src='imagenes/ajax-loader.gif' style='width: 30px;'/>");
	$("#error").html("");
	var funcionAjax=$.ajax({
		url:"https://restcountries.eu/rest/v2/region/americas",
	
	})
	.then(function(retorno){
		console.info(retorno);
		paisUno = retorno[0];
		paisDos = retorno[1];
		paisTres = retorno[2];

		$("#principal").html(
			"Nombre: " + paisUno.altSpellings[0] + "<br>" +
			"Codigo Alpha 2: " + paisUno.alpha2Code + "<br>" +
			"Area: " + paisUno.area + "<br>" +
			"Capital: " + paisUno.capital + "<br>" +

			"Nombre: " + paisDos.altSpellings[0] + "<br>" +
			"Codigo Alpha 2: " + paisDos.alpha2Code + "<br>" +
			"Area: " + paisDos.area + "<br>" +
			"Capital: " + paisDos.capital + "<br>" +

			"Nombre: " + paisTres.altSpellings[2] + "<br>" +
			"Codigo Alpha 2: " + paisTres.alpha2Code + "<br>" +
			"Area: " + paisTres.area + "<br>" +
			"Capital: " + paisTres.capital + "<br>"
		);
		$("#informe").html("Correcto MostarPaises ");	
	})
	.catch(function(retorno){
		$("#botonesABM").html(":(");
		$("#informe").html(retorno.responseText);	
	});

}

function MostarPais()
{

	$("#informe").html("<img src='imagenes/ajax-loader.gif' style='width: 30px;'/>");
	$("#error").html("");
	var funcionAjax=$.ajax({
		url:"https://restcountries.eu/rest/v2/name/argentina",
	
	})
	.then(function(retorno){
		console.info(retorno);
		$("#principal").html(
			"Nombre: " + retorno[0].altSpellings[2] + "<br>" +
			"Codigo Alpha 2: " + retorno[0].alpha2Code + "<br>" +
			"Area: " + retorno[0].area + "<br>" +
			"Capital: " + retorno[0].capital + "<br>"
		);
		$("#informe").html("Correcto MostarPais");	
	})
	.catch(function(retorno){
		$("#botonesABM").html(":(");
		$("#informe").html(retorno.responseText);	
	});

}

