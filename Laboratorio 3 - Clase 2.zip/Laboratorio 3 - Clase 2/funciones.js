function validar() {
    var nombre = $("txtUsr").value;
    var password = $("txtPass").value;

    if (nombre == "hola") {

        alert("Hola Mundo!!!");
    }
    else {
        alert("Chau");
    }


}

function $(identificador) {
    return document.getElementById(identificador);
}