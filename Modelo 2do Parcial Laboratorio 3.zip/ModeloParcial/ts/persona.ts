namespace modelo.parcial {
    export class Persona {

    }
}