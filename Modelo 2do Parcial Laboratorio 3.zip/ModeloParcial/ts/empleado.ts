///<reference path ="./persona.ts"/>
namespace modelo.parcial {
    export class Empleado extends Persona {
        public nombre:string;
    }
}