namespace modelo.parcial{

}