function MostrarMensaje()
    {
        var username = document.getElementById("usuario");
        alert(username.value);
    }

    function LimpiarCampos()
    {
        var username = document.getElementById("usuario");
        var pass = document.getElementById("pass");

        username.value = "";
        pass.value = "";
    }

    var xmlHttp = new XMLHttpRequest();
    var callBack = function(){
        console.log("Todavia no llego nada");
        if (xmlHttp.readyState === 4)
        {
            if (xmlHttp.status === 200)
            {
                console.log("Llego respuesta del servidor");
                console.log(xmlHttp.response);
            }
        }
    }


    //Primer prueba sin parametros get.
    /*function peticionGet()
    {
        xmlHttp.onreadystatechange = callBack;
        xmlHttp.open("GET","URL", true);
        xmlHttp.send();
    }*/

    //Prueba con parametros por GET
    /*function peticionGet(idUsuario,idPass)
    {
        xmlHttp.onreadystatechange = callBack;
        var usr = getElement(idUsuario).value;
        var pass = getElement(idPass).value;
        var url = "http://localhost:3000/loginUsuario";

        if(usr != "" && pass!= "")
        {
            url = url+"?usr="+usr+"&pass="+pass;
            
        }
        xmlHttp.open("GET",url, true);
        xmlHttp.send();
    }*/

    function peticionGet(idUsuario,idPass)
    {
        xmlHttp.onreadystatechange = callBack;
        
        var usr = getElement(idUsuario).value;
        var pass = getElement(idPass).value;
        var url = "http://localhost:3000/loginUsuario";
        var param = "usr="+usr+"&pass="+pass;
        console.log("---------------");

        xmlHttp.open("POST",url, true);
        //Se indica que el contenido que se va a enviar es de tipo string
        xmlHttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
        if(usr != "" && pass!= "")
        {
            xmlHttp.send(param);
        }
        else{
            xmlHttp.send();
        }
        
    }

    function getElement(id)
    {
        return document.getElementById(id);
    }

    //var world = "Hola Mundo!"
    //alert(world)

    //var username = document.getElementById("usuario");
    //alert(username.value);
    //window.onload = peticionGet;